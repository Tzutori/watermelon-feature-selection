watermelon feature selection

more information will be updated soon.